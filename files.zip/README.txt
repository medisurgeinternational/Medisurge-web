Drop your product photos in this folder using these exact filenames.
The products page will pick them up automatically — no code changes needed.
Until a file is added, that product shows a plain label instead of a broken image.

ot-table.jpg              — OT Table
ot-light.jpg               — OT Light
anesthesia-machine.jpg      — Anesthesia Machine
ventilator.jpg              — Ventilator
baby-warmer.jpg             — Baby Warmer
incubator.jpg               — Incubator
mas-hand-instruments.jpg    — MAS Hand Instruments
trocars.jpg                 — Trocars
imaging.jpg                 — Imaging Modalities (general — let me know specific modalities to split this out)

Recommended: roughly square or 4:3 photos, at least 800px wide, .jpg or .png
(if you use .png, update the file extension in products.html to match).
