// Set current year in footer
document.querySelectorAll('#year').forEach(el => {
  el.textContent = new Date().getFullYear();
});

// Contact form handler
// To make this actually send emails for free, sign up at https://formspree.io
// then change the <form> tag in contact.html to:
//   <form id="contactForm" action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
// and you can delete this JS handler below — Formspree will handle submission directly.
const form = document.getElementById('contactForm');
if (form) {
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Thanks! This form is not yet connected to an email service — see script.js for setup instructions.');
  });
}
